from nativeedge import ctx

ctx.returns({'drift': True})
